package com.isi.java.threads;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;

public class Data 
{
	private int value =0;
	private AtomicInteger atomicValue = new AtomicInteger(0);
	
	
	
	
	private ReentrantLock lock = new ReentrantLock();
	public int getVaue() 
	{
	 return value;
	}
	public int increment()
	{
		System.out.println("++value");
		return value;
		
	}
	
	public synchronized int incrementSynchronizedMethod() 
	{
		return++value;
	}
	public int incrementSynchronizedBlock()
	{
		synchronized (this) 
		{
			System.out.println(++value);
			return value;
		}
		
	}
	public int incrementLock()
	{
		lock.lock();
		try 
		{
			System.out.println(++value);
			return value;
		} 
		finally 
		{
			// TODO: handle finally clause
			lock.unlock();
		}
	}
	public int incrementAtomic()
	{
		int original=atomicValue.get();
		System.out.println(atomicValue.addAndGet(1));
		return value;
	}
}
