package com.isi.java.threads;

public class IncrementerThread extends Thread
{
	
	private Data data;
	public IncrementerThread(Data data)
	{
		super();
		this.data=data;
		
	}
	@Override
	public void run()
	{
		for (int i=0;i<10;i++)
		{
			int value;
			//value=data.increment();
			value=data.incrementSynchronizedMethod();
			
			synchronized (data) 
			{
				value=data.increment();
			}
			value=data.incrementLock();
			value
			//System.out.println(value);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {e.printStackTrace();
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
