package com.isi.java.threads;

public class Main 
{
	public static void main(String[] args)
	{
		System.out.println("main() beginning");
		Data data = new Data();
		IncrementerThread thread1 = new IncrementerThread(data); 
		IncrementerThread thread2 = new IncrementerThread(data); 
		
		System.out.println("main() starting threads....");
		
		
		thread1.start();
		thread2.start();
		
		try 
		{
			thread1.join();
			thread2.join();
		} 
		catch (InterruptedException e) {e.printStackTrace(); } 
		{
			// TODO: handle exception
		}
		System.out.println("main() exiting.....");
	}

}	

